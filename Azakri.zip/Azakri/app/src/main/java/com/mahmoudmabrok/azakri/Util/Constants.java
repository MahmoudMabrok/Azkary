package com.mahmoudmabrok.azakri.Util;

public class Constants {
    public static final String sabah_pref_key = "sabah";
    public static final String masa_pref_key = "masa";
}
