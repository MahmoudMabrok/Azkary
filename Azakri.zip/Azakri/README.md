# Azkary
- Azkar App that display Morning and evening azkar.
